new Swiper(".swiper", {
    pagination: {
      el: ".swiper-pagination",
      clickable: true
    },
    effect: 'slide', // Add slide effect
    speed: 800,
    loop: true
});